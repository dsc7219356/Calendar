//
//  ViewController.m
//  LXCalendar
//
//  Created by chenergou on 2017/11/2.
//  Copyright © 2017年 漫漫. All rights reserved.
//

#import "ViewController.h"
#import "DCDateView.h"
@interface ViewController ()<UITableViewDelegate,UITableViewDataSource,DCDateViewDelegate>
@property(nonatomic,strong)UITableView *tableview;
@property(nonatomic,strong)NSArray *dataA;
@property(nonatomic,strong)DCDateView *dateView;
@end

@implementation ViewController


- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    
    
    self.title = @"日历demo";
    self.view.backgroundColor =[UIColor whiteColor];
    self.extendedLayoutIncludesOpaqueBars = YES;
    self.automaticallyAdjustsScrollViewInsets = NO;
    [self setUp];
}
-(void)setUp{
    [self.view addSubview:self.tableview];
    
}
-(NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section{
    return self.dataA.count;
}
-(UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath{
    UITableViewCell *cell =[tableView dequeueReusableCellWithIdentifier:@"cell" forIndexPath:indexPath];
    if (!cell) {
        cell =[[UITableViewCell alloc]initWithStyle:UITableViewCellStyleDefault reuseIdentifier:@"cell"];
    }
    
    cell.textLabel.text = self.dataA[indexPath.row];
    return cell;
}
-(void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath{
    [tableView deselectRowAtIndexPath:indexPath animated:YES];
//
//    Class class = NSClassFromString([NSString stringWithFormat:@"%@Controller",self.dataA[indexPath.row]]);
//    [self.navigationController pushViewController:[class new] animated:YES];
//
    _dateView = [[[NSBundle mainBundle] loadNibNamed:@"DCDateView" owner:self options:nil] lastObject];
    _dateView.frame = CGRectMake(0, 0, Device_Width, Device_Height);
    _dateView.delegate = self;
    UIWindow *window =[UIApplication sharedApplication].keyWindow;
    [window addSubview:_dateView];

}
-(UITableView *)tableview{
    
    if (!_tableview) {
        _tableview =[[UITableView alloc]initWithFrame:CGRectMake(0, NAVH, Device_Width, Device_Height - NAVH) style:UITableViewStylePlain];
        _tableview.delegate = self;
        _tableview.dataSource = self;
        _tableview.showsVerticalScrollIndicator = NO;
        _tableview.showsHorizontalScrollIndicator = NO;
        _tableview.tableFooterView = [UIView new];
        
        [_tableview registerClass:[UITableViewCell class] forCellReuseIdentifier:@"cell"];
        
    }
    return _tableview;
}

-(NSArray *)dataA{
    if (!_dataA) {
        _dataA = @[@"LXCalendarOne"];
    }
    return _dataA;
}
-(void)getString:(NSString *)str{
    _dataA = @[str];
    [self.tableview reloadData];
}
@end
