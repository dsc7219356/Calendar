//
//  DCDateView.m
//  LXCalendar
//
//  Created by dsc on 2018/1/15.
//  Copyright © 2018年 漫漫. All rights reserved.
//

#import "DCDateView.h"
@interface DCDateView ()<UITableViewDelegate,UITableViewDataSource>
@property(nonatomic,strong)NSMutableArray *yearArray;
@property(nonatomic,copy)NSString *yearString;
@property(nonatomic,copy)NSString *monthString;
@property(nonatomic,copy)NSString *dateString;
@property(nonatomic,copy)NSString *nowYearString;

@end
@implementation DCDateView


// Only override drawRect: if you perform custom drawing.
// An empty implementation adversely affects performance during animation.
- (void)drawRect:(CGRect)rect {
    
    self.calenderView =[[LXCalendarView alloc]initWithFrame:CGRectMake(0, 0, Device_Width - 60, 350)];
    self.calenderView.currentMonthDate = [NSDate date];

    NSDateFormatter *dateFormatter = [[NSDateFormatter alloc] init];
    [dateFormatter setDateFormat:@"YYYY-MM-dd HH:mm:ss"];
    NSString *strDate = [dateFormatter stringFromDate:[NSDate date]];
    self.yearString = [strDate substringToIndex:4];
    self.nowYearString = [strDate substringToIndex:4];
    self.monthString = [strDate substringWithRange:NSMakeRange(5, 2)];
    self.dateString = [strDate substringWithRange:NSMakeRange(8, 2)];
    self.calenderView.currentMonthTitleColor =[UIColor hexStringToColor:@"2c2c2c"];
    self.calenderView.lastMonthTitleColor =[UIColor hexStringToColor:@"8a8a8a"];
    self.calenderView.nextMonthTitleColor =[UIColor hexStringToColor:@"8a8a8a"];
    
    self.calenderView.isHaveAnimation = YES;
    
    self.calenderView.isCanScroll = YES;
    self.calenderView.isShowLastAndNextBtn = YES;
    
    self.calenderView.todayTitleColor =[UIColor greenColor];
    
    self.calenderView.selectBackColor =[UIColor redColor];
    
    self.calenderView.isShowLastAndNextDate = NO;
    
    [self.calenderView dealData];
    
    self.calenderView.backgroundColor =[UIColor whiteColor];
    
    [self.calendarbgView addSubview:self.calenderView];
    __weak typeof(self) weakSelf = self;
    self.calenderView.selectBlock = ^(NSInteger year, NSInteger month, NSInteger day) {
        NSLog(@"%ld年 - %ld月 - %ld日",(long)year,month,day);
        //
        NSDateFormatter *dateFormatter = [[NSDateFormatter alloc] init];
        [dateFormatter setDateFormat:@"YYYY-MM-dd HH:mm:ss"];
        NSString *dateString = [NSString stringWithFormat:@"%ld-%ld-%ld 00:00:00",(long)year,month,day];
        
        NSDate *date = [dateFormatter dateFromString:dateString];
          NSString *strDate = [dateFormatter stringFromDate:date];
        weakSelf.yearString = [strDate substringToIndex:4];
        weakSelf.monthString = [strDate substringWithRange:NSMakeRange(5, 2)];
        weakSelf.dateString = [strDate substringWithRange:NSMakeRange(8, 2)];
        weakSelf.dateLab.text =[NSString stringWithFormat:@"%ld月%ld日%@",(long)month,day,[weakSelf weekdayStringFromDate:date]];
        [weakSelf.yearButton setTitle:weakSelf.yearString forState:UIControlStateNormal];
    };
     [self creatTableView];
  
    
}
- (IBAction)buttonClick:(id)sender {
    UIButton *button = sender;
    if (button.tag==0) {
        //取消
        [self removeFromSuperview];
    }
    else if (button.tag==1){
        //确定
        [self removeFromSuperview];
        
        NSString *chooseString = [NSString stringWithFormat:@"%@年%@月%@日",self.yearString,self.monthString,self.dateString];
        NSLog(@"选择日期为%@",chooseString);
        if (self.delegate && [self.delegate respondsToSelector:@selector(getString:)]) {
            [self.delegate getString:chooseString];
        }
    }
    else if (button.tag==2){
        //年份
       
       
        self.tableView.hidden = NO;
       
        
    }
}

- (NSString*)weekdayStringFromDate:(NSDate*)inputDate {
    
    NSArray *weekdays = [NSArray arrayWithObjects: [NSNull null], @"Sunday", @"周一", @"周二", @"周三", @"周四", @"周五", @"周六", nil];
    
    NSCalendar *calendar = [[NSCalendar alloc] initWithCalendarIdentifier:NSCalendarIdentifierGregorian];
    
    NSTimeZone *timeZone = [[NSTimeZone alloc] initWithName:@"Asia/Shanghai"];
    
    [calendar setTimeZone: timeZone];
    
    NSCalendarUnit calendarUnit = NSCalendarUnitWeekday;
    
    NSDateComponents *theComponents = [calendar components:calendarUnit fromDate:inputDate];
    
    return [weekdays objectAtIndex:theComponents.weekday];
    
}

-(void)creatTableView{
   
    if (self.tableView==nil) {
        self.yearArray = [NSMutableArray array];
        for (NSInteger i=1900;i < 2101;i++) {
            [self.yearArray addObject:@(i).stringValue];
        }
        self.tableView = [[UITableView alloc]initWithFrame:CGRectMake(30, 138, Device_Width-60, 479) style:UITableViewStylePlain];
        self.tableView.dataSource=self;
        self.tableView.delegate = self;
        [self addSubview:self.tableView];
        NSInteger row = [self.nowYearString integerValue] -1900;
        
        [self.tableView scrollToRowAtIndexPath:[NSIndexPath indexPathForRow:row-3 inSection:0] atScrollPosition:UITableViewScrollPositionTop animated:YES];
        self.tableView.hidden = YES;
    }
    else{
        self.tableView.hidden=NO;
    }
 
    
}
-(NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section{
    return self.yearArray.count;
}
-(UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath{
    UITableViewCell *cell =[tableView dequeueReusableCellWithIdentifier:@"cell"];
    if (!cell) {
        cell= [[UITableViewCell alloc]initWithStyle:UITableViewCellStyleDefault reuseIdentifier:@"cell"];
    }
    cell.textLabel.text =self.yearArray[indexPath.row];
    cell.textLabel.textAlignment =NSTextAlignmentCenter;
    if ([self.nowYearString isEqualToString:self.yearArray[indexPath.row]]) {
        cell.textLabel.textColor = [UIColor blueColor];
    }
    else{
        cell.textLabel.textColor = [UIColor blackColor];
    }
    return cell;
}
-(CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath{
    return 60;
}
-(void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath{
    
    NSString *yearString = self.yearArray[indexPath.row];
    self.yearString = yearString;
    
    [self.yearButton setTitle:yearString forState:UIControlStateNormal];
    
    self.tableView.hidden = YES;
    
    NSDateFormatter *dateFormatter = [[NSDateFormatter alloc] init];
    [dateFormatter setDateFormat:@"YYYY-MM-dd HH:mm:ss"];
    NSString *dateString = [NSString stringWithFormat:@"%@-%@-%@ 00:00:00",self.yearString,self.monthString,self.dateString];
    NSDate *date = [dateFormatter dateFromString:dateString];
    self.calenderView.currentMonthDate =date;
    self.dateLab.text =[NSString stringWithFormat:@"%@月%@日%@",self.monthString,self.dateString,[self weekdayStringFromDate:date]];
    [self.calenderView dealData];
}
@end
