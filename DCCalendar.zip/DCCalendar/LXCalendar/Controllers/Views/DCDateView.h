//
//  DCDateView.h
//  LXCalendar
//
//  Created by dsc on 2018/1/15.
//  Copyright © 2018年 漫漫. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "LXCalender.h"
@interface DCDateView : UIView
@property(nonatomic,weak)IBOutlet UIButton *yearButton;
@property(nonatomic,weak)IBOutlet UILabel *dateLab;
@property(nonatomic,weak)IBOutlet UIView *calendarbgView;
@property(nonatomic,weak)IBOutlet UIButton *cancleButton;
@property(nonatomic,weak)IBOutlet UIButton *okButton;
@property(nonatomic,strong)LXCalendarView *calenderView;
@property(nonatomic,strong)UITableView *tableView;
@property(nonatomic,assign)id delegate;
@end
@protocol DCDateViewDelegate <NSObject>
@optional
-(void)getString:(NSString *)str;

@end
