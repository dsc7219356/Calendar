//
//  LXCalendarWeekView.h
//  LXCalendar
//
//  Created by chenergou on 2017/11/2.
//  Copyright © 2017年 漫漫. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface LXCalendarWeekView : UIView
@property(nonatomic,strong)NSArray *weekTitles;
@end
